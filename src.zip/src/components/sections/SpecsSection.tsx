import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Cpu, Layout, ArrowRight } from 'lucide-react';

// --- DATA: YOUR 3 CORE VALUES ---
const capabilities = [
  {
    id: "eng",
    title: "ENGINEERING",
    subtitle: "Full-Stack Architecture",
    icon: <Layout className="w-8 h-8" />,
    description: "Building scalable, fault-tolerant web systems. I don't just write code; I engineer digital ecosystems that are robust, responsive, and ready for the future.",
    stats: ["React / Next.js", "Node.js Performance", "3D WebGL Integration"],
    color: "from-blue-600 to-cyan-600"
  },
  {
    id: "sec",
    title: "SECURITY",
    subtitle: "Defense-Grade Protocols",
    icon: <Shield className="w-8 h-8" />,
    description: "Security isn't an afterthought; it's the foundation. Implementing zero-trust architectures, end-to-end encryption, and secure communication channels for sensitive environments.",
    stats: ["Zero Trust Auth", "AES-256 Encryption", "Secure LAN Ops"],
    color: "from-emerald-600 to-green-600"
  },
  {
    id: "ai",
    title: "INTELLIGENCE",
    subtitle: "Machine Learning & AI",
    icon: <Cpu className="w-8 h-8" />,
    description: "Bridging the gap between data and decision. creating smart algorithms that analyze, predict, and optimize user experiences in real-time.",
    stats: ["Python / TensorFlow", "Computer Vision", "Predictive Models"],
    color: "from-purple-600 to-pink-600"
  }
];

export const SpecsSection = () => {
  const [active, setActive] = useState("sec"); // Default open tab

  return (
    <section className="relative h-[80vh] bg-[#050505] py-20 px-4 md:px-10 flex flex-col md:flex-row gap-4 overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none" />

      {capabilities.map((cap) => {
        const isActive = active === cap.id;
        
        return (
          <motion.div
            key={cap.id}
            onHoverStart={() => setActive(cap.id)}
            onClick={() => setActive(cap.id)} // For mobile tap
            layout // <--- This magic prop makes the size change smooth
            transition={{ type: "spring", stiffness: 200, damping: 25 }}
            className={`
              relative h-full rounded-3xl overflow-hidden cursor-crosshair border border-white/10
              ${isActive ? 'flex-[3]' : 'flex-[1]'} 
              group transition-all duration-500
            `}
          >
            {/* 1. BACKGROUND GRADIENT (Dark when closed, Glowing when open) */}
            <div className={`absolute inset-0 bg-gradient-to-b ${cap.color} transition-opacity duration-500 ${isActive ? 'opacity-20' : 'opacity-0'}`} />
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

            {/* 2. CONTENT CONTAINER */}
            <div className="relative z-10 h-full flex flex-col justify-between p-8">
              
              {/* TOP: ICON & TITLE */}
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl bg-white/10 backdrop-blur-md text-white border border-white/20 transition-colors ${isActive ? 'bg-white/20' : ''}`}>
                  {cap.icon}
                </div>
                {/* Title hides on mobile if not active to save space */}
                <div className={`${isActive ? 'opacity-100' : 'opacity-0 md:opacity-100'} transition-opacity duration-300`}>
                  <h3 className="text-xl md:text-2xl font-black text-white tracking-widest uppercase">
                    {cap.title}
                  </h3>
                  {isActive && (
                    <p className="text-sm text-zinc-400 font-mono mt-1">{cap.subtitle}</p>
                  )}
                </div>
              </div>

              {/* MIDDLE: VERTICAL TITLE (Only visible when CLOSED) */}
              {!isActive && (
                <div className="absolute inset-0 flex items-center justify-center opacity-0 md:opacity-100 transition-opacity delay-200">
                  <h3 className="-rotate-90 text-4xl font-black text-white/20 tracking-[0.2em] whitespace-nowrap uppercase">
                    {cap.title}
                  </h3>
                </div>
              )}

              {/* BOTTOM: DESCRIPTION (Only visible when OPEN) */}
              {isActive && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <p className="text-lg text-zinc-300 leading-relaxed mb-8 max-w-2xl">
                    {cap.description}
                  </p>
                  
                  {/* STATS PILLS */}
                  <div className="flex flex-wrap gap-3">
                    {cap.stats.map((stat, i) => (
                      <span key={i} className="px-4 py-2 rounded-full border border-white/10 bg-white/5 text-sm font-mono text-white/80 uppercase tracking-wider">
                        {stat}
                      </span>
                    ))}
                  </div>

                  {/* DECORATIVE ARROW */}
                  <div className="mt-8 flex items-center gap-2 text-white/40 text-xs font-mono uppercase tracking-widest">
                    <span>System Ready</span>
                    <div className="h-px w-12 bg-white/20" />
                  </div>
                </motion.div>
              )}

            </div>

            {/* HOVER GLOW EFFECT */}
            <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent z-0" />
          </motion.div>
        );
      })}

    </section>
  );
};