import React from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { User, Code, Heart, Zap } from 'lucide-react';

const AboutSection = () => {
  // --- 3D TILT LOGIC ---
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseX = useSpring(x, { stiffness: 150, damping: 15 });
  const mouseY = useSpring(y, { stiffness: 150, damping: 15 });

  const rotateX = useTransform(mouseY, [-0.5, 0.5], ["15deg", "-15deg"]);
  const rotateY = useTransform(mouseX, [-0.5, 0.5], ["-15deg", "15deg"]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <section className="relative min-h-screen bg-[#050505] py-32 px-6 flex items-center justify-center overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-900/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-20 items-center relative z-10">
        
        {/* LEFT: THE HOLOGRAPHIC ID CARD (Interactive) */}
        <motion.div
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
          className="relative w-full max-w-md mx-auto aspect-[3/4] rounded-3xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-md shadow-2xl p-6 flex flex-col justify-between group"
        >
          {/* Internal Glow */}
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl pointer-events-none" />
          
          {/* Card Header */}
          <div className="flex justify-between items-start transform translate-z-10">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center text-2xl">
              👾
            </div>
            <div className="text-right">
              <h3 className="text-xs font-mono text-zinc-400 uppercase tracking-widest">Clearance Level</h3>
              <p className="text-xl font-bold text-white">LVL. 21</p> {/* Age or 'Level' */}
            </div>
          </div>

          {/* Card Image / Avatar */}
          <div className="relative flex-1 my-6 rounded-2xl overflow-hidden border border-white/10 bg-black/20 group-hover:scale-[1.02] transition-transform duration-500">
             {/* Replace with your photo or 3D avatar */}
             <img 
               src="public/memoji.png" 
               alt="Profile" 
               className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" 
             />
             <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
               <p className="font-mono text-xs text-green-400 animate-pulse">● ONLINE</p>
             </div>
          </div>

          {/* Card Footer */}
          <div className="space-y-2 transform translate-z-10">
            <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Kalpesh</h2>
            <p className="text-sm text-zinc-400 font-mono">
              Computer Engineer <span className="text-purple-500">///</span> Defense Intern
            </p>
          </div>
        </motion.div>

        {/* RIGHT: THE NARRATIVE (Text) */}
        <div className="space-y-8">
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-xs font-bold text-purple-500 tracking-[0.3em] uppercase mb-4">
              // The Dossier
            </h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
              Architecting the <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                Future of Defense
              </span>
            </h3>
            
            <p className="text-lg text-zinc-400 leading-relaxed mb-6">
              I am a 3rd-year Computer Engineering student with a rare focus: 
              <b> High-Security Systems</b>. While others build simple apps, I am currently interning 
              at a Defense Company, crafting <b>LAN-based secure communication protocols</b> that 
              don't rely on the open internet.
            </p>

            <p className="text-lg text-zinc-400 leading-relaxed">
              But I'm not just code. I have a creative obsession with <b>3D Technologies</b> and 
              <b> Holographic Telepresence</b>. My goal isn't just to write software; it's to build 
              immersive, secure digital realities.
            </p>
          </motion.div>

          {/* Personality Toggles / Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <Code className="w-6 h-6 text-blue-400 mb-2" />
              <h4 className="font-bold text-white">The Engineer</h4>
              <p className="text-xs text-zinc-500 mt-1">Python, C++, System Design</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <Zap className="w-6 h-6 text-yellow-400 mb-2" />
              <h4 className="font-bold text-white">The Creator</h4>
              <p className="text-xs text-zinc-500 mt-1">3D Art, Figurines, Design</p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

export { AboutSection };