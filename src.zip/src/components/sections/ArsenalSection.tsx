import { motion } from 'framer-motion';
import { GlassCard } from '../ui/GlassCard';

const skills = [
  { name: 'C', category: 'language', level: 90 },
  { name: 'C++', category: 'language', level: 85 },
  { name: 'Python', category: 'language', level: 88 },
  { name: 'JavaScript', category: 'language', level: 80 },
  { name: 'Node.js', category: 'stack', level: 75 },
  { name: 'HTML/CSS', category: 'stack', level: 90 },
  { name: 'SQL', category: 'stack', level: 82 },
  { name: 'Android Studio', category: 'stack', level: 70 },
  { name: 'GitHub', category: 'stack', level: 85 },
  { name: 'German (A2)', category: 'language', level: 40 },
  { name: 'Machine Learning', category: 'specialty', level: 75 },
  { name: '3D Modeling', category: 'specialty', level: 65 },
];

const categoryColors: Record<string, string> = {
  language: 'from-primary to-neon-blue',
  stack: 'from-secondary to-neon-pink',
  specialty: 'from-neon-pink to-primary',
};

export const ArsenalSection = () => {
  return (
    <section id="arsenal" className="relative min-h-screen py-32 overflow-hidden">
      <div className="container mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="font-mono text-sm text-primary uppercase tracking-widest mb-4 block">
            // Technical Capabilities
          </span>
          <h2 className="text-4xl md:text-6xl font-orbitron font-bold mb-4">
            The <span className="neon-text-cyan">Arsenal</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A comprehensive toolkit forged through academic rigor and real-world application
          </p>
        </motion.div>

        {/* Skills floating sphere visualization */}
        <div className="relative">
          {/* 3D-like floating skill tags */}
          <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.5, y: 50 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  duration: 0.5, 
                  delay: index * 0.08,
                  type: 'spring',
                  stiffness: 100
                }}
                whileHover={{ 
                  scale: 1.1, 
                  zIndex: 10,
                  transition: { duration: 0.2 }
                }}
                className="relative group"
                style={{
                  transform: `translateZ(${Math.random() * 50}px)`,
                }}
              >
                <div className={`
                  px-6 py-3 rounded-full
                  bg-gradient-to-r ${categoryColors[skill.category]}
                  bg-opacity-20 backdrop-blur-md
                  border border-primary/30
                  font-orbitron text-sm font-medium
                  cursor-pointer
                  transition-all duration-300
                  hover:border-primary hover:shadow-[0_0_20px_hsl(180_100%_50%/0.4)]
                `}>
                  <span className="text-foreground">{skill.name}</span>
                  
                  {/* Level indicator on hover */}
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileHover={{ opacity: 1, y: 0 }}
                    className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap"
                  >
                    <span className="text-xs text-primary font-mono">{skill.level}%</span>
                  </motion.div>
                </div>

                {/* Glow effect */}
                <div className={`
                  absolute inset-0 rounded-full opacity-0 group-hover:opacity-30
                  bg-gradient-to-r ${categoryColors[skill.category]}
                  blur-xl transition-opacity duration-300 -z-10
                `} />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Category legend */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8 }}
          className="flex justify-center gap-8 mt-16"
        >
          {[
            { label: 'Languages', category: 'language' },
            { label: 'Tech Stack', category: 'stack' },
            { label: 'Specialties', category: 'specialty' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${categoryColors[item.category]}`} />
              <span className="text-sm text-muted-foreground font-mono">{item.label}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
