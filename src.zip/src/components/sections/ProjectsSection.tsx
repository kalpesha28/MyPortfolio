import React, { useRef } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion';
import { Map, Palette, Shield, Rocket, ExternalLink, Github } from 'lucide-react';

// --- DATA ---
const projects = [
  // Replace the old projects array (or JSX) with this:

{
  title: "GhostLAN",
  description: "Offline Encrypted Messaging System. A secure chat tool built with Java & Networking that works without internet.",
  image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=2600", // Matrix/Cyber style
  tags: ["Java", "Networking", "Security"],
  link: "#" // Add your GitHub link here later
},
{
  title: "Space Explorer",
  description: "Gamified Learning with NASA APIs. An educational platform that makes learning space concepts fun.",
  image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2600", // Space style
  tags: ["Web Dev", "API", "NASA"],
  link: "#" 
}
];

// --- INDIVIDUAL CARD COMPONENT ---
const Card = ({ 
  i, 
  project, 
  progress, 
  range, 
  targetScale 
}: { 
  i: number; 
  project: any; 
  progress: MotionValue<number>; 
  range: number[]; 
  targetScale: number; 
}) => {
  const container = useRef(null);
  
  // ANIMATION LOGIC:
  // Scale: Cards shrink slightly as they go back in the stack
  const scale = useTransform(progress, range, [1, targetScale]);
  
  return (
    <div ref={container} className="h-screen flex items-center justify-center sticky top-0">
      <motion.div 
        style={{ scale, top: `calc(-5vh + ${i * 25}px)` }} 
        className="relative flex flex-col w-[90vw] max-w-[1000px] h-[70vh] rounded-3xl p-10 origin-top overflow-hidden border border-white/10 shadow-2xl"
      >
        {/* DYNAMIC BACKGROUND */}
        <div className={`absolute inset-0 bg-gradient-to-br ${project.color} opacity-20`} />
        <div className="absolute inset-0 bg-black/80 backdrop-blur-3xl" /> // Glass layer
        
        {/* CARD CONTENT */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12 h-full items-center">
          
          {/* LEFT: TEXT */}
          <div className="flex flex-col gap-6">
            <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center backdrop-blur-md border border-white/20">
              {project.icon}
            </div>
            
            <h2 className="text-4xl md:text-6xl font-black text-white uppercase leading-none">
              {project.title}
            </h2>
            
            <p className="text-lg text-zinc-400 leading-relaxed">
              {project.description}
            </p>

            <div className="flex flex-wrap gap-2">
              {project.tags.map((tag: string, idx: number) => (
                <span key={idx} className="px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs tracking-wider uppercase">
                  {tag}
                </span>
              ))}
            </div>

            <div className="flex gap-4 mt-4">
              <button className="flex items-center gap-2 px-6 py-3 rounded-full bg-white text-black font-bold hover:scale-105 transition-transform">
                View Project <ExternalLink size={16} />
              </button>
              <button className="flex items-center gap-2 px-6 py-3 rounded-full border border-white/20 hover:bg-white/10 transition-colors">
                <Github size={16} /> Source
              </button>
            </div>
          </div>

          {/* RIGHT: VISUAL / IMAGE PLACEHOLDER */}
          {/* We use a 'skew' effect here to make it look movable/3D */}
          <div className="relative h-full w-full rounded-2xl overflow-hidden border border-white/10 bg-black/40 group">
             {/* Replace this with an actual screenshot of your project later */}
             <div className={`absolute inset-0 bg-gradient-to-br ${project.color} opacity-40 group-hover:opacity-60 transition-opacity duration-500`} />
             
             <div className="absolute inset-0 flex items-center justify-center">
               <span className="text-9xl font-black text-white/5 group-hover:scale-110 transition-transform duration-700">
                 0{i + 1}
               </span>
             </div>
             
             {/* Floating UI Element (Simulates a screenshot) */}
             <div className="absolute bottom-10 right-10 left-10 h-1/2 bg-zinc-900/80 backdrop-blur-md rounded-t-xl border-t border-l border-r border-white/10 transform translate-y-full group-hover:translate-y-4 transition-transform duration-500 ease-out p-4">
               <div className="flex gap-2 mb-2">
                 <div className="w-2 h-2 rounded-full bg-red-500"/>
                 <div className="w-2 h-2 rounded-full bg-yellow-500"/>
                 <div className="w-2 h-2 rounded-full bg-green-500"/>
               </div>
               <div className="w-full h-2 bg-white/10 rounded-full mb-2"/>
               <div className="w-2/3 h-2 bg-white/10 rounded-full"/>
             </div>
          </div>

        </div>
      </motion.div>
    </div>
  );
};

// --- MAIN EXPORT ---
export const ProjectsSection = () => {
  const container = useRef(null);
  
  // Track scroll progress of the ENTIRE container
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end end']
  });

  return (
    // Height needs to be (number of projects) * 100vh roughly to give scroll space
    <div ref={container} className="relative bg-black text-white pb-[20vh]">
      
      {/* SECTION HEADER */}
      <div className="h-[50vh] flex items-center justify-center sticky top-0 z-0">
        <div className="text-center">
          <h2 className="text-xs font-mono text-purple-400 tracking-widest mb-4 uppercase">Selected Works</h2>
          <h3 className="text-5xl md:text-7xl font-bold">The Archive</h3>
        </div>
      </div>

      {/* RENDER CARDS */}
      <div className="relative z-10">
        {projects.map((project, i) => {
          // Calculate scale for the stacking effect
          const targetScale = 1 - ((projects.length - i) * 0.05);
          return (
            <Card 
              key={i} 
              i={i} 
              project={project} 
              progress={scrollYProgress}
              range={[i * 0.25, 1]}
              targetScale={targetScale}
            />
          );
        })}
      </div>
    </div>
  );
};