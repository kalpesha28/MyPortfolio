import React from 'react';
import { motion } from 'framer-motion';
import { 
  Code2, Database, Globe, Cpu, Terminal, 
  Layers, Shield, Brain, Rocket, Wifi 
} from 'lucide-react';

// --- DATA: THE ARSENAL ---
// Broken into two rows for the "Opposite Scroll" effect
const row1 = [
  { name: "Python", icon: <Code2 /> },
  { name: "C++", icon: <Terminal /> },
  { name: "TensorFlow", icon: <Brain /> },
  { name: "React", icon: <Globe /> },
  { name: "Node.js", icon: <Cpu /> },
  { name: "Three.js", icon: <Layers /> },
];

const row2 = [
  { name: "Defense Sec", icon: <Shield /> },
  { name: "SQL", icon: <Database /> },
  { name: "Socket.io", icon: <Wifi /> },
  { name: "Space API", icon: <Rocket /> },
  { name: "Git", icon: <Code2 /> },
  { name: "Linux", icon: <Terminal /> },
];

// --- COMPONENT: THE INFINITE LANE ---
const InfiniteLoop = ({ items, direction }: { items: any[], direction: "left" | "right" }) => {
  return (
    <div className="flex relative overflow-hidden mask-gradient">
      {/* WRAPPER FOR SMOOTH ANIMATION */}
      <motion.div 
        initial={{ x: direction === "left" ? 0 : "-50%" }}
        animate={{ x: direction === "left" ? "-50%" : 0 }}
        transition={{ 
          duration: 20, 
          ease: "linear", 
          repeat: Infinity 
        }}
        className="flex gap-8 py-4 px-4 pr-12 min-w-max"
      >
        {/* We duplicate the list 4 times to ensure seamless infinite scrolling */}
        {[...items, ...items, ...items, ...items].map((item, i) => (
          <div 
            key={i}
            className="group relative flex items-center gap-4 px-8 py-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm transition-all hover:bg-white/10 hover:border-purple-500/50 hover:scale-105 cursor-crosshair"
          >
            {/* GLOW EFFECT ON HOVER */}
            <div className="absolute inset-0 bg-purple-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <div className="relative z-10 text-purple-400 group-hover:text-white transition-colors">
              {React.cloneElement(item.icon, { size: 28 })}
            </div>
            <span className="relative z-10 text-xl font-bold text-zinc-400 group-hover:text-white uppercase tracking-wider">
              {item.name}
            </span>
          </div>
        ))}
      </motion.div>
    </div>
  );
};

// --- MAIN EXPORT ---
export const SkillsSection = () => {
  return (
    <section className="relative bg-[#050505] py-32 overflow-hidden flex flex-col justify-center">
      
      {/* BACKGROUND DECOR */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/10 via-[#050505] to-[#050505]" />
      
      <div className="relative z-10 mb-16 px-6 text-center">
        <h2 className="text-sm font-mono text-purple-500 tracking-[0.5em] uppercase mb-4">
          The Arsenal
        </h2>
        <h3 className="text-4xl md:text-6xl font-black text-white uppercase">
          Technical <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">Mastery</span>
        </h3>
      </div>

      {/* 3D TILTED CONTAINER */}
      {/* The 'rotate' and 'skew' classes create the 3D perspective */}
      <div className="relative flex flex-col gap-8 -rotate-3 hover:rotate-0 transition-transform duration-700 ease-out py-10">
        
        {/* ROW 1: Moves Left */}
        <InfiniteLoop items={row1} direction="left" />
        
        {/* ROW 2: Moves Right */}
        <InfiniteLoop items={row2} direction="right" />

      </div>

      {/* VIGNETTE FADE (Sides fade to black) */}
      <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#050505] to-transparent z-20 pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#050505] to-transparent z-20 pointer-events-none" />

    </section>
  );
};