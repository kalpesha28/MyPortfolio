import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';

// --- HELPER: FLOATING DEBRIS ---
// Generates random tech bits (0s, 1s, squares) to fill the void
const FloatingParticles = () => {
  // Create an array of 20 random particles
  const particles = Array.from({ length: 20 });
  
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
      {particles.map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            x: Math.random() * window.innerWidth, 
            y: Math.random() * window.innerHeight,
            opacity: 0.2 
          }}
          animate={{ 
            y: [null, Math.random() * -100], // Float up
            opacity: [0.1, 0.5, 0.1], // Pulse
          }}
          transition={{ 
            duration: Math.random() * 10 + 10, // Random speed (10-20s)
            repeat: Infinity,
            ease: "linear" 
          }}
          className="absolute"
        >
          {/* Randomly choose a shape: A small square or a bit of text */}
          {i % 2 === 0 ? (
            <div className="w-1 h-1 bg-purple-500/40 rounded-full blur-[1px]" />
          ) : (
            <span className="text-[10px] font-mono text-white/10">{Math.random() > 0.5 ? '1' : '0'}</span>
          )}
        </motion.div>
      ))}
    </div>
  );
};

// --- MAIN COMPONENT ---
export const HeroSection = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  // 1. MOUSE SPOTLIGHT LOGIC
  const handleMouseMove = (e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
  };

  // 2. SCROLL ANIMATION HOOKS
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  // Zoom: From 1x to 20x (Super deep fly-through)
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 20]);
  // Fade: Text disappears as you get "too close"
  const opacity = useTransform(scrollYProgress, [0, 0.4], [1, 0]);
  // Subtext: Moves faster (Parallax)
  const ySubtext = useTransform(scrollYProgress, [0, 1], [0, 800]);

  return (
    <section 
      ref={containerRef} 
      onMouseMove={handleMouseMove}
      className="relative h-[250vh] bg-[#050505] overflow-hidden"
    >
      
      {/* --- LAYER 0: MOUSE SPOTLIGHT --- */}
      {/* This creates a glow wherever your mouse moves, fixing the "flat black" look */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 transition-opacity duration-300"
        style={{
          background: `radial-gradient(600px circle at ${mousePos.x}px ${mousePos.y}px, rgba(120, 50, 255, 0.08), transparent 40%)`
        }}
      />

      {/* --- LAYER 1: CYBER GRID FLOOR --- */}
      {/* Adds perspective so it doesn't look like floating in nothingness */}
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center perspective-1000">
        
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:60px_60px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_70%,transparent_100%)] z-0" />
        
        {/* --- LAYER 2: FLOATING PARTICLES --- */}
        <FloatingParticles />

        {/* --- LAYER 3: THE MAIN CONTENT (ZOOMING) --- */}
        <motion.div 
          style={{ scale, opacity }} 
          className="relative z-20 flex flex-col items-center justify-center"
        >
          {/* Decorative Top Label */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mb-8 flex items-center gap-3 px-4 py-2 border border-white/10 rounded-full bg-white/5 backdrop-blur-md"
          >
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-zinc-400 font-mono tracking-widest uppercase">System Online</span>
          </motion.div>

          {/* MASSIVE TEXT */}
          <h1 className="text-[15vw] leading-[0.85] font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white via-white to-gray-500 select-none drop-shadow-2xl">
            KALPESHA
          </h1>
          
          {/* SUBTEXT PARALLAX */}
          <motion.div style={{ y: ySubtext }} className="mt-12 text-center">
             <p className="text-xl md:text-3xl font-light text-zinc-400 tracking-[0.3em] uppercase mb-4">
              Engineering <span className="text-purple-500 mx-2">•</span> Intelligence
            </p>
            {/* Scroll Indicator */}
            <div className="flex flex-col items-center gap-2 opacity-50">
              <span className="text-[10px] uppercase tracking-widest">Scroll to Enter</span>
              <div className="w-px h-12 bg-gradient-to-b from-white to-transparent" />
            </div>
          </motion.div>

        </motion.div>

        {/* --- LAYER 4: VIGNETTE & GRAIN --- */}
        {/* Makes it look like a movie screen */}
        <div className="absolute inset-0 pointer-events-none z-50 bg-[radial-gradient(circle_at_center,transparent_0%,#000000_100%)] opacity-80" />
        
      </div>
    </section>
  );
};